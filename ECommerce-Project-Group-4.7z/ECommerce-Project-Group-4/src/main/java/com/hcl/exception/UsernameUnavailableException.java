package com.hcl.exception;

public class UsernameUnavailableException extends Exception {
	public UsernameUnavailableException(String message) {
		super(message);
	}
}
